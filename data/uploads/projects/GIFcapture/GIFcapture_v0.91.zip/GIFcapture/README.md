GIFcapture
----------

GIFcapture is a program that captures your screen into an animated .gif file. 

  - Requires the [Python Imaging Library].
  - Windows only. Linux support will be added later.


---

###Acknowledgements###

The images2gif module by Almar Klein is used in this program. 

Copyright (c) 2010, Almar Klein, Ant1, Marius van Voorden.



---


Capture and render settings can be changed in the etc/settings.py file. 



**Licensed under the GNU General Public License Version 3.**

  [Python Imaging Library]: http://www.pythonware.com/products/pil/

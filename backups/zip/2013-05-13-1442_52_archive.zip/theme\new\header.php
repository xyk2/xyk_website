				<header class="row">
					<hgroup>
						<a href='/'><h1 class="col span_2">XYK</h1></a>
					</hgroup>
					<nav id="global_nav" class="row">
						<h2 class="col span_2" id="projects">PROJECTS</h2>
						<h2 class="col span_2" id="sandbox">SANDBOX</h2>
						<h2 class="col span_2" id="about"><a href='/about/'>ABOUT</a></h2>
						<div class="col span_1" id='nav_spacer'>.</div>
						<div class="col span_3" id='icons'>
							<a href='https://twitter.com/xiaoyangkao2'><i class="twitter"></i></a>
							<a href='https://plus.google.com/u/0/100717066473058120846'><i class="googleplus"></i></a>
							<a href='#'><i class="email"></i></a>
							<a href='http://www.youtube.com/xiaoyangkao2'><i class="youtube"></i></a>
							<a href='#'><i class="rss"></i></a>
						</div>
					</nav>
				</header>
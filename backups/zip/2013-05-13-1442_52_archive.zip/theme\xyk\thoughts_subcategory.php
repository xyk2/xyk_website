<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
<head>
	<title><?php get_page_title(); ?> - xyk</title>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<link rel="shortcut icon" href="http://d30cz35xum7wy8.cloudfront.net/static/favicon.png"/>
  	<link rel="stylesheet" type="text/css" href="/theme/xyk/css/thoughts_subcategory.css" media="all" />
  	<link rel="stylesheet" type="text/css" href="/theme/xyk/css/style_social_media.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="/theme/xyk/css/style_sidebar.css" media="all"/>
	<link rel="author" href="https://plus.google.com/100717066473058120846/">

	<?php get_header(); ?>	

	<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-32156965-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

</head>

<body>
	<div id='navigation'>
		<div id='logo'>
			<h4><a style='color:#9D3B73' href="<?php get_site_url(); ?>">xyk</a></h4>
		</div>
		<div id='sidebar'>
			<ul>
				<?php get_component('sidebar'); ?>
			</ul>
		</div>
	<?php get_component('social_media'); ?>
	</div>

	<div id='content'>	
		<h1 style='font-family:ubuntu-regular;font-size:35px;padding-top:30px;color:#77216F;'>
			thoughts</h1>
		<h3 style='font-family:ubuntu-light;font-size:16px;padding-top:5px;'>
		Thoughts and opinions.
		</h3>
		
		<div class='text' id='text'>
		<?php get_page_content() ?>
		</div>
	</div>

</body>
</html>

	<footer id='footer_sticky' class="row footer">
		<div class='container' style='max-width:960px;margin:0 auto;'>
			<div class="col span_2">
				<div class="footer_center">
					<i class="github monochrome" style=""></i>
					<p>Github</p>
				</div>
			</div>
			<div class='col span_2'>
				<div class="footer_center">
					<i class='picasa monochrome' style=""></i>
					<p>Picasa</p>
				</div>
			</div>
			<div class='col span_2'>
				<div class="footer_center">
					<i class='flickr monochrome' style=""></i>
					<p>Flickr</p>
				</div>
			</div>
			<div class='col span_2'>
				<div class="footer_center">
					<i class='lastfm monochrome'  style=""></i>
					<p>Last.fm</p>
				</div>
			</div>
			<!-- 
			<div class='col span_4' style='text-align: center;padding-right: 2.5%;'>
				<form style='float:right;' action="http://xy-kao.us7.list-manage.com/subscribe/post?u=c3703f7768c221e5f97a384f5&amp;id=aab0fadc54" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
					<div class="input-append">
						<input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="Email address"  style='width:190px;border-radius:7px 0 0 7px;' autocorrect="off" spellcheck="false" required>
						<button type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="btn" style='border-radius:0 7px 7px 0;background-color: #34495E;color: rgba(255, 255, 255, 0.86);'>Sign Up</button>
					</div>
				</form>
			</div>
			-->
		</div>
	</footer>
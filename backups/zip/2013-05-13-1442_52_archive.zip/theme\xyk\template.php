<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
<head>
	<title><?php get_page_title(); ?> - xyk</title>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<link rel="shortcut icon" href="http://d30cz35xum7wy8.cloudfront.net/static/favicon.png"/>
  	<link rel="stylesheet" type="text/css" href="/theme/xyk/css/style_posts.css" media="all" />
	<link rel="stylesheet" type="text/css" href="/theme/xyk/css/style_social_media.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="/theme/xyk/css/style_sidebar.css" media="all"/>
	<script type="text/javascript" src="/theme/xyk/js/gplus.js"></script>
	<script type="text/javascript" src="/theme/xyk/js/twitter.js"></script>
	<script type="text/javascript" src="/theme/xyk/js/google_analytics.js"></script>
	<link rel="author" href="https://plus.google.com/100717066473058120846/">

	<?php get_header(); ?>	
</head>

<body>
	<div id='navigation'>
		<div id='logo'>
			<h4 style='font-size:inherit;'> <a style='color:#9D3B73' href="<?php get_site_url(); ?>">xyk</a></h4>
		</div>
		<div id='sidebar'>
			<ul>
				<?php get_component('sidebar'); ?>
			</ul>
		</div>
	<?php get_component('social_media'); ?>
	</div>

	<div id='content'>		
		<div id='listing'>
			<h1 class='title'><a href="<?php get_page_url(); echo '">'; get_page_title();?></a></h1>	

			<div id='dateTag'>
				<?php // HEADER DATE AND TAG INFORMATION
					$error = return_page_slug(); // check for 404
					echo "posted ";
					if($error != "404") { 
						echo return_custom_field('creation_date'); //echo creation date
						echo ' - updated ';
						echo strtolower(get_page_date('F j', false)); // echo last update
					} else {
						echo strtolower(date("F j, Y")); // if 404, echo current date
					}
					echo ' | tagged as <a href="';
					get_site_url(); 
					get_parent();
					echo '">';
					if($error != "404") { // return error tag if 404
						get_parent();
					} else {
						echo "error";
					}
					echo "</a>";
				?>
				<div style='float:right;'> <!-- Tweet and Google+ buttons -->
					<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fxy-kao.com%2Fprojects%2Fvirtual-graphics-for-swimming%2F&amp;send=false&amp;layout=button_count&amp;width=100&amp;show_faces=false&amp;font&amp;colorscheme=light&amp;action=like&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>
					<a href="https://twitter.com/share" class="twitter-share-button">Tweet</a> 
					<g:plusone size="medium"></g:plusone></div>
			</div>
			
			<div id='text'>
				<?php 
				$error = return_page_slug();
				if($error != "404") { 
					get_page_content();
				} else {
					echo "<p>The page you are looking for does not exist.</p>";
				}
				?>
			</div>
			<div style='padding-top:50px;width:80%;'>

				
				        <div id="disqus_thread"></div>
        <script type="text/javascript">
            /* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
            var disqus_shortname = 'xyk2'; // required: replace example with your forum shortname

            /* * * DON'T EDIT BELOW THIS LINE * * */
            (function() {
                var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                dsq.src = 'http://' + disqus_shortname + '.disqus.com/embed.js';
                (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
            })();
        </script>
        <noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
        <a href="http://disqus.com" class="dsq-brlink">comments powered by <span class="logo-disqus">Disqus</span></a>
				
			</div>

		</div>
		

	</div>

</body>

</html>
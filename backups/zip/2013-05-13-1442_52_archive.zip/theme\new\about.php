<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>projects and experiments by Xiaoyang Kao</title>
		<link rel="shortcut icon" href="/theme/new/img/favicon.png"/>
 		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <link rel="stylesheet" type='text/css' href="/theme/new/grid_css/reset.css">
        <link rel="stylesheet" type='text/css' href="/theme/new/grid_css/responsive-gs-12col.css">
        <link rel="stylesheet/less" type='text/css' href="/theme/new/style.less">
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
		<script src="/theme/new/less-1.3.3.min.js" type="text/javascript"></script>

    </head>

    <body>
		<div style='max-width:960px;margin:0 auto;'>
			<div id="page_wrap" class="container row">
				<?php include('/theme/new/header.php'); ?>
				
				


				
				<section id="content_wrap" class="row">
					<div class="col span_12 clr" id='about_body'>
						<img id='self_photo' src="/theme/new/img/sample_mini.jpg">
						<h2 style="font-weight: bold;font-size: 18px;">Xiaoyang Kao</h2>
						<h2 style="font-size: 14px;">Student</h2>
						<p>I am a student who enjoys making things. On this site you will find old and current projects I am working on either in school or on my own time.</p>
						<p>In the spirit of the open-source movement, everything on this site is under a <a href='http://creativecommons.org/licenses/by-nc-sa/3.0/'>Creative Commons Attribution-Non Commercial-Share Alike v3.0</a> license. You can open up that link to read the full description (or the longer legal code), but it means you may use the content here as long as it is attributed, shared under the same license, and used for non-commercial purposes.</p>
						<p>If you want to contact me, email me or leave a comment.</p>
					</div>
					
				</section>

				
				<!-- content_wrap -->
				
			</div><!-- page_wrap -->
		</div>
		<?php include('/theme/new/footer.php'); ?>
	
    </body>
</html>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>projects, experiments of Xiaoyang Kao</title>
		<link rel="shortcut icon" href="/theme/new/img/favicon.png"/>
 		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <link rel="stylesheet" type='text/css' href="/theme/new/grid_css/reset.css">
        <link rel="stylesheet" type='text/css' href="/theme/new/grid_css/responsive-gs-12col.css">
        <link rel="stylesheet/less" type='text/css' href="/theme/new/style.less">
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
		<script src="/theme/new/less-1.3.3.min.js" type="text/javascript"></script>

    </head>

    <body>
		<div style='max-width:960px;margin:0 auto;'>
			<div id="page_wrap" class="container row">
				<?php include('/theme/new/header.php'); ?>
				
								
				<section id="content_wrap" class="row">
					<?php 
					/*<div class="row article_row">
						<article class="col span_12 clr front_page_article">
							<img src="/theme/new/img/header.jpg" style="width: 41%;">
							<a href='./template.php'><h2>Virtual Lane Graphics for Swimming with CSS3 and HTML5</h2></a>
							<div style='margin-top: 2px;'>
								<span class="flatui-16 fui-time-16 post_date-glyph"></span>
								<h3>February 16, 2013</h3>
								<span class="flatui-16 fui-menu-16 category-glyph"></span>
								<h3 style='float:none'>Projects</h3>
							</div>
							<p>
								If you watched any of the Olympic swimming events last year on television, you probably saw something like this: Pretty cool stuff...
								<span class="read_more">Read...</span>
							</p>
						</article>
					</div>*/ 
					?>
					<?php 
						/* Removes <p> tags and &nbsp; from CKEditor output */
						/* Eval()'s home page and runs embedded PHP code to generate homepage */
						$content = returnPageContent(return_page_slug()); 
						$new_content = strip_tags($content);
						$new_content = str_replace(array('&nbsp;', '&nbsp'), '', $new_content);
						eval($new_content);
					?>
				</section>

				<?php 
					function homepage_listing($title, $url, $post_date, $category, $image_url, $excerpt, $custom_image_width='40%', $excerpt_length=250) {
						echo "<div class='row article_row'>
						<article class='col span_12 clr front_page_article'>
							<img src='{$image_url}' style='width:{$custom_image_width};'>
							<a href='{$url}'><h2>{$title}</h2></a>
							<div style='margin-top: 2px;'>
								<span class='flatui-16 fui-time-16 post_date-glyph'></span>
								<h3>{$post_date}</h3>
								<span class='flatui-16 fui-menu-16 category-glyph'></span>
								<h3 style='float:none'>{$category}</h3>
							</div>
							<p>
								{$excerpt}
								<a href='{$url}'><span class='read_more'>Read...</span></a>
							</p>
						</article>
					</div>";
					}
				?>
				<!-- content_wrap -->
				
			</div><!-- page_wrap -->
		</div>
		<?php include('/theme/new/footer.php'); ?>
	
    </body>
</html>
